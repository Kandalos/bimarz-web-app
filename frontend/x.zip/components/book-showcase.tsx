import { BookCard } from "@/components/book-card"

const books = [
  {
    id: 1,
    title: "باد مرگ",
    author: "سروش مظفر مقدم",
    description:
      "کاوشی تکان‌دهنده در حافظه و از دست دادن در پس‌زمینه یک ایستگاه نجومی فراموش‌شده. ویتمور روایتی فراتر از زمان می‌بافد و فضاهای بین آنچه به یاد می‌آوریم و آنچه می‌خواهیم فراموش کنیم را بررسی می‌کند.",
    year: "۱۴۰۳",
    genre: "داستان ادبی",
    image: "/elegant-book-cover-with-observatory-theme-minimali.jpg",
  },
  {
    id: 2,
    title: "به از نفس اقتادگان",
    author: "مریم نوری ",
    description:
      "تصویری صمیمی از سه نسل که در پیچیدگی‌های هویت و تعلق حرکت می‌کنند. نثر کاستلانو نخ‌های نامرئی را روشن می‌کند که ما را به گذشته‌مان پیوند می‌دهد و در عین حال به سوی آینده‌ای نامعلوم سوق می‌دهد.",
    year: "۱۴۰۳",
    genre: "داستان معاصر",
    image: "/sophisticated-book-cover-with-geometric-lines-mode.jpg",
  },
]

export function BookShowcase() {
  return (
    <section id="books" className="py-24 px-6 wood-texture bg-wood-light/5">
      {/* </CHANGE> */}
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-4 text-balance">انتشارات اخیر</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">دستاوردهای ادبی جدید ما را کشف کنید</p>
        </div>
        <div className="grid md:grid-cols-2 gap-12 lg:gap-16">
          {books.map((book) => (
            <BookCard key={book.id} book={book} />
          ))}
        </div>
      </div>
    </section>
  )
}
