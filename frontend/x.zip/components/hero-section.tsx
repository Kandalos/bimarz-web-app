"use client"

export function HeroSection() {
  const nudeColors = [
    "#D4B5A0", // warm beige
    "#E8D5C4", // cream
    "#C9A88A", // tan
    "#E5C9B5", // soft peach
    "#B89F91", // taupe
    "#DCC5B0", // light brown
    "#F0E4D7", // ivory
    "#C4A792", // muted brown
    "#E0CFC1", // pale tan
    "#BFA58F", // dusty beige
    "#D9C3B0", // sand
    "#CDB5A0", // warm taupe
  ]

  return (
    <section className="relative min-h-screen flex items-center justify-center px-6 py-20 pt-32 overflow-hidden wood-texture bg-gradient-to-b from-wood-light/30 to-background">
      <div className="absolute inset-0 z-0 opacity-15">
        <svg
          className="w-full h-full"
          viewBox="0 0 1182.99 864"
          preserveAspectRatio="xMidYMid slice"
          xmlns="http://www.w3.org/2000/svg"
        >
          <g
            className="svg-drawing-animation"
            fill="none"
            stroke="#492116"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            {/* All paths from the SVG file */}
            <path d="M810,500c-1.83.68-4.3-.69-4.05,3.45.2,18.72,3.21,37.38,4.09,56.01.07,1.57.95,16.25-1.04,15.54l-4-46v42h-3s1.89-45.39,1.89-45.39l-2.64-24.16c.27-1.38,8.07-3.6,8.74-1.45Z" />
            <path d="M497,0l76.51,10.99c51.18,4.08,101.94,12.22,153.03,16.54L795,0h2l-68.51,28.99-1.48,43.01,43.51-15.07c13.99,3.11,30.03,2.59,43.8,5.3,2.08.41,2.29,1.02,3.14,2.74l68.95-21.85c1.34-.95.96-28.39,1.65-32.56.29-1.75,1.88-4.9,3.46-5.55,2.87-1.18.94,8.83,1.5,9.99l7.98-8.99c-1.25,4.85-8.13,9.81-8.94,14.55-1.14,6.72.36,16.7-.02,23.98-.43,8.19-3.52,25.01-2.57,31.98.25,1.85,7.26,12.26,9.05,12.53l21.48-4.06-10-61.99c5.47,2.92,11.18-4.99,14.6,1.91l4.74-.87.69-6.01c3.57.9,5.92-2.56,8.53-3.02,4.47-.78,11.64,2.14,16.43,1.99h-14.99s11.49,51.98,11.49,51.98c2.14-2.08,3.14-4.91,4.66-7.38.71-1.16,2.59-1.39,2.85-2.33,1.42-5.14-.22-23.79-.04-30.82.12-4.81.46-9.82.7-14.65.06-1.21-.99-2.27,1.32-2.82l-.98,63.99,2.28-2.16,2.72-65.83c2.94-.61,1.95,1.39,2.02,3.52.45,12.84-5.08,42.07-.06,52.01,1.59,3.15,5.06,6.13,6.68,9.54l17.35-4.08-13.5-54.97-2.55,1.65,8.04,52.33-1.73-1.75-8.96-50.79,7.21-4.45,12.58,56.92c.36.24,8.53-.2,7.89-2.38l-13.97-56.54c1.95.35,1.63,2.11,2.03,3.46,5.23,17.43,7.97,36.01,12.96,53.55.35.35,7.35-1.45,8.59-1.91,1.17-.43,1.62.62,1.37-1.53l-15.97-52.55c2.17-.43,2.32.97,3.06,2.43,4,7.93,6.65,25.72,9.68,35.32.74,2.35,4.35,14.73,5.84,15.1l6.25-2.32-12.81-47.54c1.68.28,1.79,1.95,2.27,3.22,5.07,13.36,7.31,30.87,11.72,44.79l17.98-4.52c1.31-4.89,14.02-18.33,14.02-21.98V9.5c0-.12,1.87-2.33,2.01-1l-.99,43.5,3.03-1.68,1.97-40.31c1.77.69,1.12,5.93,1.04,7.54-.27,4.93-2.24,12.02-.84,16.74.33,1.13,10.25,12.25,11.42,12.48l98.37-23.77c.42,2.45-.29,1.86-1.98,2.46-14.63,5.18-34.59,7.06-50.22,10.83-19.32,4.66-38.64,10.13-57.65,15.85l-.13,4.85c35.43-10.47,71.18-19.02,107.51-26l1.49,2-22.98,5.5,13.98,13.5v-17c3.17-1.05,2.15,5.57,2.04,7.54-.89,16.38-1.26,32.64-2,49-.82,18.11-3.57,36.28-3.03,54.45,4.48-1.21,11.18-2.68,15.81-2.78,1.6-.03,2.72-.11,3.18,1.77l-85.33,9.18-36.03,5.79-.65,3.03-.99-1.99h-3s0,3.99,0,3.99l133.98-16.5-97.99,15.51v16c4.44-4.32,10.31-10.2,12.01-16,1.93-.15,2.63,1.51,4.55,1.94,16.77,3.75,34.69,4.12,51.64,7.37,1.79.34,5.62-.03,4.79,2.69l-59.97-9.99-12.02,15.98,28,3.02-.02,3.98-28.98-3.99,12.99,16.99,60.01-10.99c-.41,2.03-2.09,1.65-3.51,1.98-8.84,2.03-18.05.31-26.97,1.03-10.87.87-21.56,3.84-32.51,3.98.41-1.99,2.04-1.7,3.5-1.99,19.13-3.81,40.09-2.78,59.5-4.99l-127.99,13c-1.58-1.21-.01-1.82,1.48-2,37.44-4.4,75.08-7.55,112.51-12.01l-33.64-17.85-69.98-33.11-230.38,17.97,76.7,60.78,103.31-10.32.99,1.52-103.38,11.75-81.28-63.08-6.33-6.66c38.24-.93,76.36-5.98,114.51-8.99,42.62-3.36,85.44-4.71,127.88-9.99,24.05,11.67,47.22,25.14,71.25,36.84,12.78,6.22,29.47,11.73,41.41,18.59,1.49.86,3.34,1.34,2.94,3.54l-127.99,13c-1.58-1.21-.01-1.82,1.48-2,37.44-4.4,75.08-7.55,112.51-12.01l-33.64-17.85-69.98-33.11-230.38,17.97,76.7,60.78,103.31-10.32.99,1.52-103.38,11.75-81.28-63.08-6.33-6.66c38.24-.93,76.36-5.98,114.51-8.99,42.62-3.36,85.44-4.71,127.88-9.99Z" />
            <path d="M143,484l-139.01,5.49,136.82-8.67,1.17-6.82-134.99,5.99c.38-1.82,1.97-1.86,3.46-2.02,14.44-1.62,33.11-.3,48.08-.92,2.37-.1,4.55-.98,6.92-1.08,24.83-1.04,49.71-1.49,74.53-2.97l-23.94-27.44c-17.15.98-34.41.87-51.59,1.41-2.3.07-10.02,3.18-9.45-.95l62.41-2.83,26.07,29.89,1.52,31.94-19.07,1.58,2.94,186.78-1.5,1.4-28.85,3.29c-3.2-.45-4.04-5.8-4.55-8.53l2.02.98-1.01-35.5-15,1.01-3.44-147.01c-.97-1.3-1.57-.81-2.75-.78-20.8.56-41.59,2.89-62.27,3.82-2.05.09-5.34.93-4.53-2.03l135.99-7.01v-19ZM124,506l-31,1.01c1.66,25.98,1.39,52.4,1.96,78.53.67,31.05.26,64.13,2,95,.14,2.46,1.32,15.33,2.66,15.53l26.38-3.06-2-187.01ZM91.99,507.01l-13,.99,4.01,146.01,12-1-3.01-146Z" />
            <path d="M457.99,405.01l-1.48,2c-144.47.28-288.81,8.25-433.13,7.12-5.69.16-13.37,2.65-18.38-.63l452.99-8.49Z" />
            <path d="M105.99,469.99l-99.99,5,2.5-1.96,94.5-5.04-12.7-15.83c-8.52,1.55-17.19.6-25.79.85-3.33.1-5.63,1.97-9.53.5-2.88-1.08.74-1.58.79-2.02l-.78-1.49,37.02-.52,13.98,20.51Z" />
            <path d="M53,434v32.5c-3.31,4.23-21.03,5.25-22.01.01-.41-2.16-.27-17.75-.98-18.52l-25.01.49c-.66-2.31,2.14-1.45,3.49-1.49,7.22-.25,14.31-1.02,21.52-.99.94-5.36-3.99-9.67,2-12.5s14.75-1.4,21,.5ZM50,436.99c-3.89-4.1-12.84-1.56-17.99-.98.02,1.7,3.31,1.88,4.49,1.99,4.34.42,9.28.17,13.5-1.02ZM32,441.5c-.14,4.83.1,9.68,0,14.5,4.37-4.29,7.65-2.31,12.99-1.99l-12,1.98.06,10.95c6.19,1.36,11.85,1.41,17.97-.42l-.04-27.53c-4.82,1.11-9.62,1.12-14.56,1.06-1.63-.02-3.71-1.05-3.95-1.03-2.4.15-.48,2.34-.48,2.47Z" />
          </g>
        </svg>
      </div>
      {/* </CHANGE> */}

      <div className="absolute top-20 left-0 z-20">
        <div className="relative w-48 h-48">
          <img
            src="/torn-corner.jpg"
            alt=""
            className="w-full h-full object-contain"
            style={{
              filter: "drop-shadow(4px 4px 12px rgba(0,0,0,0.2))",
              maskImage: "radial-gradient(ellipse at top left, black 40%, transparent 85%)",
              WebkitMaskImage: "radial-gradient(ellipse at top left, black 40%, transparent 85%)",
            }}
          />
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-8 pr-8 pb-8">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-wood-dark hover:text-wood-medium transition-colors"
            >
              <i className="lni lni-instagram text-7xl"></i>
            </a>
            <a
              href="https://youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-wood-dark hover:text-wood-medium transition-colors"
            >
              <i className="lni lni-youtube text-7xl"></i>
            </a>
          </div>
        </div>
      </div>

      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <div
            key={`book-${i}`}
            className={`absolute text-4xl opacity-30 ${
              i % 3 === 0 ? "animate-rain" : i % 3 === 1 ? "animate-rain-delayed" : "animate-rain-slow"
            }`}
            style={{
              left: `${(i * 15) % 100}%`,
              animationDelay: `${i * 1.2}s`,
            }}
          >
            <i className="lni lni-book" style={{ color: nudeColors[i % nudeColors.length] }}></i>
          </div>
        ))}
        {[...Array(6)].map((_, i) => (
          <div
            key={`pen-${i}`}
            className={`absolute text-3xl opacity-25 ${
              i % 3 === 0 ? "animate-rain-slow" : i % 3 === 1 ? "animate-rain" : "animate-rain-delayed"
            }`}
            style={{
              left: `${(i * 15 + 5) % 100}%`,
              animationDelay: `${i * 1.5}s`,
            }}
          >
            <i className="lni lni-pencil" style={{ color: nudeColors[(i + 3) % nudeColors.length] }}></i>
          </div>
        ))}
        {[...Array(6)].map((_, i) => (
          <div
            key={`coffee-${i}`}
            className={`absolute text-3xl opacity-25 ${
              i % 3 === 0 ? "animate-rain-delayed" : i % 3 === 1 ? "animate-rain-slow" : "animate-rain"
            }`}
            style={{
              left: `${(i * 15 + 10) % 100}%`,
              animationDelay: `${i * 1.8}s`,
            }}
          >
            <i className="lni lni-coffee-cup" style={{ color: nudeColors[(i + 6) % nudeColors.length] }}></i>
          </div>
        ))}
      </div>

      <div className="max-w-5xl mx-auto text-center relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          {/* Main Hero Content */}
          <div>
            <div className="mb-12">
              <div className="inline-block mb-8 p-6 rounded-lg border-2 border-wood-medium/40 shadow-lg relative overflow-hidden">
                <svg
                  className="absolute inset-0 w-full h-full"
                  xmlns="http://www.w3.org/2000/svg"
                  style={{ opacity: 0.6 }}
                >
                  <defs>
                    <pattern id="brickPattern" x="0" y="0" width="96" height="48" patternUnits="userSpaceOnUse">
                      <rect x="0" y="0" width="45" height="21" fill="#8B4513" stroke="#654321" strokeWidth="0.5" />
                      <rect x="48" y="0" width="45" height="21" fill="#A0522D" stroke="#654321" strokeWidth="0.5" />
                      <rect x="-24" y="24" width="45" height="21" fill="#D2691E" stroke="#654321" strokeWidth="0.5" />
                      <rect x="24" y="24" width="45" height="21" fill="#CD853F" stroke="#654321" strokeWidth="0.5" />
                      <rect x="72" y="24" width="45" height="21" fill="#8B4513" stroke="#654321" strokeWidth="0.5" />
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#brickPattern)" />
                </svg>
                {/* </CHANGE> */}
                <img src="/logo.svg" alt="cafe schalpate" className="w-24 h-24 relative z-10" />
              </div>
              <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight mb-8 text-balance leading-[1.2] text-wood-dark">
                نغمه‌ای از طعم و فرهنگ
              </h1>
              <p className="text-base md:text-lg text-wood-dark/70 max-w-xl mx-auto leading-relaxed text-pretty">
                در کافه شال‌پلاته، هر فنجان قهوه با نوایی از فرهنگ و خاطره همراه است. جایی که صدای صفحه‌های قدیمی در هوای
                کلن می‌پیچد و گفت‌وگوها با لطافت موسیقی و عطر قهوه در هم می‌آمیزند.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <a
                href="#books"
                className="inline-flex items-center justify-center px-8 py-3 bg-wood-medium text-white rounded-lg hover:bg-wood-dark transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 wood-texture"
              >
                {"کتاب فروشی"}
              </a>
              <a
                href="#contact"
                className="inline-flex items-center justify-center px-8 py-3 border-2 border-wood-medium text-wood-dark rounded-lg hover:bg-wood-light/30 transition-all duration-300 wood-texture"
              >
                کافه شالپلاته
              </a>
            </div>
          </div>

          {/* Newsletter Titles Section */}
          <div className="bg-wood-light/20 backdrop-blur-sm border-2 border-wood-medium/40 rounded-lg p-6 wood-texture shadow-xl">
            <div className="flex items-center gap-3 mb-6">
              <i className="lni lni-write text-3xl text-wood-dark"></i>
              <h2 className="text-2xl md:text-3xl font-bold text-wood-dark">خبرنامه‌ها</h2>
            </div>
            <div className="space-y-4 max-h-96 overflow-y-auto">
              {[
                { id: 1, title: "رویدادهای فرهنگی بهار ۱۴۰۳", date: "۱۵ اسفند ۱۴۰۲" },
                { id: 2, title: "معرفی کتاب‌های جدید ماه", date: "۱۰ اسفند ۱۴۰۲" },
                { id: 3, title: "نشست‌های ادبی هفته", date: "۵ اسفند ۱۴۰۲" },
                { id: 4, title: "گزارش رونمایی کتاب", date: "۱ اسفند ۱۴۰۲" },
              ].map((newsletter) => (
                <a
                  key={newsletter.id}
                  href={`/newsletter#${newsletter.id}`}
                  className="block p-4 bg-white/80 rounded-lg border-2 border-wood-light/60 hover:border-wood-medium transition-all hover:shadow-md group"
                >
                  <h3 className="font-bold text-wood-dark group-hover:text-wood-medium transition-colors mb-2">
                    {newsletter.title}
                  </h3>
                  <p className="text-sm text-wood-dark/60">{newsletter.date}</p>
                </a>
              ))}
            </div>
            <a
              href="/newsletter"
              className="mt-6 block text-center px-6 py-2 bg-wood-medium text-white rounded-lg hover:bg-wood-dark transition-colors font-bold"
            >
              مشاهده همه خبرنامه‌ها
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}
