import Link from "next/link"
import { Button } from "@/components/ui/button"
import { TrendingUp } from "lucide-react"

const mostBoughtBooks = [
  {
    id: 6,
    title: "شازده کوچولو",
    author: "آنتوان دو سنت اگزوپری",
    price: "۸۵,۰۰۰",
    soldCount: 1250,
    image: "/little-prince-persian-book-cover.jpg",
  },
  {
    id: 7,
    title: "صد سال تنهایی",
    author: "گابریل گارسیا مارکز",
    price: "۱۶۵,۰۰۰",
    soldCount: 980,
    image: "/one-hundred-years-solitude-book-cover.jpg",
  },
  {
    id: 8,
    title: "کلیدر",
    author: "محمود دولت‌آبادی",
    price: "۲۲۰,۰۰۰",
    soldCount: 875,
    image: "/kelidar-book-cover.jpg",
  },
  {
    id: 9,
    title: "سووشون",
    author: "سیمین دانشور",
    price: "۱۳۵,۰۰۰",
    soldCount: 820,
    image: "/savushun-book-cover.jpg",
  },
  {
    id: 10,
    title: "بوف کور",
    author: "صادق هدایت",
    price: "۹۵,۰۰۰",
    soldCount: 765,
    image: "/buf-koor-book-cover.jpg",
  },
]

export function MostBoughtBooksSection() {
  return (
    <section className="py-24 px-6 bg-wood-light/10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <TrendingUp className="w-8 h-8 text-wood-medium" />
            <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-balance text-wood-dark">
              پرفروش‌ترین کتاب‌ها
            </h2>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">محبوب‌ترین انتخاب‌های خوانندگان ما</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-12">
          {mostBoughtBooks.map((book) => (
            <Link key={book.id} href={`/shop/${book.id}`}>
              <div className="group bg-white rounded-lg border-2 border-wood-light/40 overflow-hidden hover:border-wood-medium transition-all hover:shadow-xl wood-texture h-full">
                <div className="relative aspect-[3/4] overflow-hidden">
                  <img
                    src={book.image || "/placeholder.svg"}
                    alt={book.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 right-2 bg-wood-dark text-white px-3 py-1 rounded-md flex items-center gap-1 text-sm font-semibold">
                    <TrendingUp className="w-4 h-4" />
                    <span>{book.soldCount}</span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-base text-wood-dark mb-1 line-clamp-1">{book.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-1">{book.author}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold text-wood-medium">{book.price} تومان</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center">
          <Link href="/shop">
            <Button className="bg-wood-medium hover:bg-wood-dark text-white px-8 py-6 text-lg">
              مشاهده همه کتاب‌ها
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
