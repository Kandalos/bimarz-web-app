import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Star } from "lucide-react"

const recommendedBooks = [
  {
    id: 1,
    title: "باد مرگ",
    author: "سروش مظفر مقدم",
    price: "۱۲۰,۰۰۰",
    rating: 4.8,
    image: "/elegant-book-cover-with-observatory-theme-minimali.jpg",
  },
  {
    id: 2,
    title: "به از نفس اقتادگان",
    author: "مریم نوری",
    price: "۱۵۰,۰۰۰",
    rating: 4.9,
    image: "/sophisticated-book-cover-with-geometric-lines-mode.jpg",
  },
  {
    id: 3,
    title: "دیوان حافظ",
    author: "حافظ شیرازی",
    price: "۹۰,۰۰۰",
    rating: 5.0,
    image: "/hafez-divan-book-cover.jpg",
  },
  {
    id: 4,
    title: "تاریخ ایران",
    author: "احمد کسروی",
    price: "۱۸۰,۰۰۰",
    rating: 4.7,
    image: "/iran-history-book-cover.jpg",
  },
  {
    id: 5,
    title: "گلستان سعدی",
    author: "سعدی شیرازی",
    price: "۱۰۰,۰۰۰",
    rating: 4.9,
    image: "/golestan-saadi-book-cover.jpg",
  },
]

export function RecommendedBooksSection() {
  return (
    <section className="py-24 px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight mb-4 text-balance text-wood-dark">
            کتاب‌های پیشنهادی ما
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">برگزیده‌های ویژه که نباید از دست بدهید</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-12">
          {recommendedBooks.map((book) => (
            <Link key={book.id} href={`/shop/${book.id}`}>
              <div className="group bg-white rounded-lg border-2 border-wood-light/40 overflow-hidden hover:border-wood-medium transition-all hover:shadow-xl wood-texture h-full">
                <div className="relative aspect-[3/4] overflow-hidden">
                  <img
                    src={book.image || "/placeholder.svg"}
                    alt={book.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-2 right-2 bg-wood-medium text-white px-2 py-1 rounded-md flex items-center gap-1 text-sm">
                    <Star className="w-4 h-4 fill-current" />
                    <span>{book.rating}</span>
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-base text-wood-dark mb-1 line-clamp-1">{book.title}</h3>
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-1">{book.author}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-lg font-bold text-wood-medium">{book.price} تومان</span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center">
          <Link href="/shop">
            <Button className="bg-wood-medium hover:bg-wood-dark text-white px-8 py-6 text-lg">
              مشاهده همه کتاب‌ها
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
