"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart } from "lucide-react"
import Link from "next/link"

export default function ShopPage() {
  const [selectedCategory, setSelectedCategory] = useState("all")

  const categories = [
    { id: "all", label: "همه" },
    { id: "fiction", label: "داستان" },
    { id: "poetry", label: "شعر" },
    { id: "history", label: "تاریخ" },
    { id: "philosophy", label: "فلسفه" },
    { id: "science", label: "علمی" },
  ]

  const books = [
    {
      id: 1,
      title: "باد مرگ",
      author: "سروش مظفر مقدم",
      price: "۱۲۰,۰۰۰",
      category: "fiction",
      image: "/elegant-book-cover-with-observatory-theme-minimali.jpg",
      inStock: true,
    },
    {
      id: 2,
      title: "به از نفس اقتادگان",
      author: "مریم نوری",
      price: "۱۵۰,۰۰۰",
      category: "fiction",
      image: "/sophisticated-book-cover-with-geometric-lines-mode.jpg",
      inStock: true,
    },
    {
      id: 3,
      title: "دیوان حافظ",
      author: "حافظ شیرازی",
      price: "۹۰,۰۰۰",
      category: "poetry",
      image: "/placeholder.svg?height=400&width=300",
      inStock: true,
    },
    {
      id: 4,
      title: "تاریخ ایران",
      author: "احمد کسروی",
      price: "۱۸۰,۰۰۰",
      category: "history",
      image: "/placeholder.svg?height=400&width=300",
      inStock: false,
    },
  ]

  const filteredBooks = selectedCategory === "all" ? books : books.filter((book) => book.category === selectedCategory)

  return (
    <main className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-24">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold text-wood-dark">فروشگاه کتاب</h1>
            <Link href="/cart">
              <Button className="bg-wood-medium hover:bg-wood-dark text-white">
                <ShoppingCart className="w-5 h-5 ml-2" />
                سبد خرید
              </Button>
            </Link>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-3 mb-8">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className={
                  selectedCategory === category.id
                    ? "bg-wood-medium hover:bg-wood-dark text-white"
                    : "border-wood-medium text-wood-dark hover:bg-wood-light/30"
                }
              >
                {category.label}
              </Button>
            ))}
          </div>

          {/* Books Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredBooks.map((book) => (
              <Link key={book.id} href={`/shop/${book.id}`}>
                <div className="group bg-white rounded-lg border-2 border-wood-light/40 overflow-hidden hover:border-wood-medium transition-all hover:shadow-xl wood-texture">
                  <div className="relative aspect-[3/4] overflow-hidden">
                    <img
                      src={book.image || "/placeholder.svg"}
                      alt={book.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {!book.inStock && (
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <Badge variant="destructive" className="text-lg px-4 py-2">
                          ناموجود
                        </Badge>
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="font-bold text-lg text-wood-dark mb-1 line-clamp-1">{book.title}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{book.author}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-xl font-bold text-wood-medium">{book.price} تومان</span>
                      {book.inStock && (
                        <Button size="sm" className="bg-wood-medium hover:bg-wood-dark text-white">
                          خرید
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
