"use client"

import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { User, Mail, Phone, MapPin, Package } from "lucide-react"
import Link from "next/link"

export default function ProfilePage() {
  // Sample user data
  const user = {
    name: "علی محمدی",
    email: "ali.mohammadi@example.com",
    phone: "۰۹۱۲۳۴۵۶۷۸۹",
    postNumber: "۱۲۳۴۵۶۷۸۹۰",
    address: "تهران، خیابان ولیعصر، پلاک ۱۲۳",
    avatar: "/placeholder.svg?height=120&width=120",
    joinDate: "۱ فروردین ۱۴۰۲",
    ordersCount: 12,
  }

  return (
    <main className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-24">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold text-wood-dark mb-8">پروفایل کاربری</h1>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Profile Card */}
            <Card className="md:col-span-1 border-2 border-wood-light/40 wood-texture">
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="w-32 h-32 mb-4 border-4 border-wood-light">
                    <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                    <AvatarFallback className="text-2xl bg-wood-light text-white">
                      {user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <h2 className="text-2xl font-bold text-wood-dark mb-2">{user.name}</h2>
                  <p className="text-sm text-muted-foreground mb-4">عضو از {user.joinDate}</p>
                  <Link href="/profile/edit" className="w-full">
                    <Button className="w-full bg-wood-medium hover:bg-wood-dark text-white">ویرایش پروفایل</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Information Cards */}
            <div className="md:col-span-2 space-y-6">
              {/* Contact Information */}
              <Card className="border-2 border-wood-light/40 wood-texture">
                <CardHeader>
                  <CardTitle className="text-wood-dark flex items-center gap-2">
                    <User className="w-5 h-5" />
                    اطلاعات تماس
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Mail className="w-5 h-5 text-wood-medium mt-1" />
                    <div>
                      <p className="text-sm text-muted-foreground">ایمیل</p>
                      <p className="font-medium text-wood-dark">{user.email}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="w-5 h-5 text-wood-medium mt-1" />
                    <div>
                      <p className="text-sm text-muted-foreground">شماره تماس</p>
                      <p className="font-medium text-wood-dark">{user.phone}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Package className="w-5 h-5 text-wood-medium mt-1" />
                    <div>
                      <p className="text-sm text-muted-foreground">کد پستی</p>
                      <p className="font-medium text-wood-dark">{user.postNumber}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-wood-medium mt-1" />
                    <div>
                      <p className="text-sm text-muted-foreground">آدرس</p>
                      <p className="font-medium text-wood-dark">{user.address}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Statistics */}
              <Card className="border-2 border-wood-light/40 wood-texture">
                <CardHeader>
                  <CardTitle className="text-wood-dark">آمار خریدها</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-wood-light/10 rounded-lg">
                      <p className="text-3xl font-bold text-wood-dark mb-1">{user.ordersCount}</p>
                      <p className="text-sm text-muted-foreground">سفارش ثبت شده</p>
                    </div>
                    <div className="text-center p-4 bg-wood-light/10 rounded-lg">
                      <p className="text-3xl font-bold text-wood-dark mb-1">۸</p>
                      <p className="text-sm text-muted-foreground">کتاب خریداری شده</p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <Link href="/profile/orders" className="w-full">
                      <Button className="w-full bg-wood-medium hover:bg-wood-dark text-white">
                        <Package className="w-4 h-4 ml-2" />
                        مشاهده تاریخچه خریدها
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
