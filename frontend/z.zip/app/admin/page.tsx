"use client"

import { useState } from "react"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { Package } from "lucide-react"

type Event = {
  id: number
  title: string
  date: string
  time: string
  location: string
  description: string
  image?: string
  category?: string
  tags?: string[]
}

type Book = {
  id: number
  title: string
  author: string
  pages: number
  year: number
  description: string
  cover?: string
  genre?: string
  isbn?: string
  price?: number
}

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState<"events" | "books">("events")

  const [events, setEvents] = useState<Event[]>([
    {
      id: 1,
      title: "نشست کتابخوانی",
      date: "2024-03-15",
      time: "18:00",
      location: "سالن اصلی",
      description: "بحث و گفتگو درباره آخرین کتاب منتشر شده",
    },
    {
      id: 2,
      title: "رونمایی کتاب جدید",
      date: "2024-03-20",
      time: "17:00",
      location: "تالار وحدت",
      description: "معرفی و رونمایی از کتاب جدید نویسنده برجسته",
    },
  ])

  const [books, setBooks] = useState<Book[]>([
    {
      id: 1,
      title: "سفر به ستارگان",
      author: "علی محمدی",
      pages: 320,
      year: 1402,
      description: "داستانی جذاب درباره کاوش فضایی",
    },
    {
      id: 2,
      title: "راز باغ",
      author: "سارا احمدی",
      pages: 280,
      year: 1401,
      description: "رمانی عاشقانه با پایانی غیرمنتظره",
    },
  ])

  const [editingEvent, setEditingEvent] = useState<Event | null>(null)
  const [editingBook, setEditingBook] = useState<Book | null>(null)

  const handleDeleteEvent = (id: number) => {
    if (confirm("آیا از حذف این رویداد اطمینان دارید؟")) {
      setEvents(events.filter((event) => event.id !== id))
    }
  }

  const handleDeleteBook = (id: number) => {
    if (confirm("آیا از حذف این کتاب اطمینان دارید؟")) {
      setBooks(books.filter((book) => book.id !== id))
    }
  }

  const handleEditEvent = (event: Event) => {
    setEditingEvent(event)
  }

  const handleEditBook = (book: Book) => {
    setEditingBook(book)
  }

  const handleCancelEdit = () => {
    setEditingEvent(null)
    setEditingBook(null)
  }

  return (
    <main className="min-h-screen bg-background">
      <Navbar />

      <div className="container mx-auto px-4 py-24">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold text-wood-dark mb-8 text-center">پنل مدیریت</h1>

          <div className="mb-8">
            <Link href="/admin/purchases">
              <Button className="bg-wood-medium hover:bg-wood-dark text-white font-bold">
                <Package className="w-5 h-5 ml-2" />
                مدیریت خریدها
              </Button>
            </Link>
          </div>

          {/* Tab Navigation */}
          <div className="flex gap-4 mb-8 border-b-2 border-wood-light/30">
            <button
              onClick={() => setActiveTab("events")}
              className={`px-6 py-3 font-bold transition-colors ${
                activeTab === "events"
                  ? "text-wood-dark border-b-4 border-wood-medium"
                  : "text-wood-medium hover:text-wood-dark"
              }`}
            >
              مدیریت رویدادها
            </button>
            <button
              onClick={() => setActiveTab("books")}
              className={`px-6 py-3 font-bold transition-colors ${
                activeTab === "books"
                  ? "text-wood-dark border-b-4 border-wood-medium"
                  : "text-wood-medium hover:text-wood-dark"
              }`}
            >
              مدیریت کتاب‌ها
            </button>
          </div>

          {/* Events Section */}
          {activeTab === "events" && (
            <div className="space-y-8">
              <div className="bg-white p-8 rounded-lg shadow-lg border-2 border-wood-light/40 wood-texture">
                <h2 className="text-2xl font-bold text-wood-dark mb-6">رویدادهای موجود</h2>
                <div className="space-y-4">
                  {events.map((event) => (
                    <div
                      key={event.id}
                      className="p-4 border-2 border-wood-light/40 rounded-lg hover:border-wood-medium/60 transition-colors"
                    >
                      <div className="flex justify-between items-start gap-4">
                        <div className="flex-1">
                          <h3 className="text-xl font-bold text-wood-dark mb-2">{event.title}</h3>
                          <p className="text-wood-medium mb-2">
                            <span className="font-bold">تاریخ:</span> {event.date} - {event.time}
                          </p>
                          <p className="text-wood-medium mb-2">
                            <span className="font-bold">مکان:</span> {event.location}
                          </p>
                          <p className="text-wood-dark/80">{event.description}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleEditEvent(event)}
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            ویرایش
                          </Button>
                          <Button
                            onClick={() => handleDeleteEvent(event.id)}
                            className="bg-red-600 hover:bg-red-700 text-white"
                          >
                            حذف
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Events Form */}
              <div className="bg-white p-8 rounded-lg shadow-lg border-2 border-wood-light/40 wood-texture">
                <h2 className="text-2xl font-bold text-wood-dark mb-6">
                  {editingEvent ? "ویرایش رویداد" : "افزودن رویداد جدید"}
                </h2>
                <form className="space-y-6">
                  <div>
                    <Label htmlFor="event-title" className="text-wood-dark font-bold mb-2 block">
                      عنوان رویداد
                    </Label>
                    <Input
                      id="event-title"
                      placeholder="عنوان رویداد را وارد کنید"
                      className="border-wood-light focus:border-wood-medium"
                      defaultValue={editingEvent?.title}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="event-date" className="text-wood-dark font-bold mb-2 block">
                        تاریخ
                      </Label>
                      <Input
                        id="event-date"
                        type="date"
                        className="border-wood-light focus:border-wood-medium"
                        defaultValue={editingEvent?.date}
                      />
                    </div>
                    <div>
                      <Label htmlFor="event-time" className="text-wood-dark font-bold mb-2 block">
                        ساعت
                      </Label>
                      <Input
                        id="event-time"
                        type="time"
                        className="border-wood-light focus:border-wood-medium"
                        defaultValue={editingEvent?.time}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="event-location" className="text-wood-dark font-bold mb-2 block">
                      مکان
                    </Label>
                    <Input
                      id="event-location"
                      placeholder="مکان برگزاری را وارد کنید"
                      className="border-wood-light focus:border-wood-medium"
                      defaultValue={editingEvent?.location}
                    />
                  </div>

                  <div>
                    <Label htmlFor="event-description" className="text-wood-dark font-bold mb-2 block">
                      توضیحات
                    </Label>
                    <Textarea
                      id="event-description"
                      placeholder="توضیحات رویداد را وارد کنید"
                      rows={5}
                      className="border-wood-light focus:border-wood-medium"
                      defaultValue={editingEvent?.description}
                    />
                  </div>

                  <div>
                    <Label htmlFor="event-image" className="text-wood-dark font-bold mb-2 block">
                      تصویر رویداد
                    </Label>
                    <Input
                      id="event-image"
                      type="file"
                      accept="image/*"
                      className="border-wood-light focus:border-wood-medium"
                    />
                  </div>

                  <div>
                    <Label htmlFor="event-category" className="text-wood-dark font-bold mb-2 block">
                      دسته‌بندی
                    </Label>
                    <select
                      id="event-category"
                      className="w-full px-4 py-2 border-2 border-wood-light rounded-lg focus:border-wood-medium focus:outline-none"
                      defaultValue={editingEvent?.category}
                    >
                      <option value="">انتخاب دسته‌بندی</option>
                      <option value="literary">ادبی</option>
                      <option value="cultural">فرهنگی</option>
                      <option value="workshop">کارگاه</option>
                      <option value="launch">رونمایی</option>
                      <option value="discussion">نشست</option>
                    </select>
                  </div>

                  <div>
                    <Label htmlFor="event-tags" className="text-wood-dark font-bold mb-2 block">
                      برچسب‌ها (با کاما جدا کنید)
                    </Label>
                    <Input
                      id="event-tags"
                      placeholder="مثال: شعر، رمان، داستان"
                      className="border-wood-light focus:border-wood-medium"
                      defaultValue={editingEvent?.tags?.join(", ")}
                    />
                  </div>

                  <div className="flex gap-4">
                    <Button className="flex-1 bg-wood-medium hover:bg-wood-dark text-white font-bold py-3">
                      {editingEvent ? "ذخیره تغییرات" : "افزودن رویداد"}
                    </Button>
                    {editingEvent && (
                      <Button
                        type="button"
                        onClick={handleCancelEdit}
                        className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-3"
                      >
                        انصراف
                      </Button>
                    )}
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* Books Section */}
          {activeTab === "books" && (
            <div className="space-y-8">
              <div className="bg-white p-8 rounded-lg shadow-lg border-2 border-wood-light/40 wood-texture">
                <h2 className="text-2xl font-bold text-wood-dark mb-6">کتاب‌های موجود</h2>
                <div className="space-y-4">
                  {books.map((book) => (
                    <div
                      key={book.id}
                      className="p-4 border-2 border-wood-light/40 rounded-lg hover:border-wood-medium/60 transition-colors"
                    >
                      <div className="flex justify-between items-start gap-4">
                        <div className="flex-1">
                          <h3 className="text-xl font-bold text-wood-dark mb-2">{book.title}</h3>
                          <p className="text-wood-medium mb-2">
                            <span className="font-bold">نویسنده:</span> {book.author}
                          </p>
                          <p className="text-wood-medium mb-2">
                            <span className="font-bold">صفحات:</span> {book.pages} |{" "}
                            <span className="font-bold">سال:</span> {book.year}
                          </p>
                          <p className="text-wood-dark/80">{book.description}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            onClick={() => handleEditBook(book)}
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            ویرایش
                          </Button>
                          <Button
                            onClick={() => handleDeleteBook(book.id)}
                            className="bg-red-600 hover:bg-red-700 text-white"
                          >
                            حذف
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Books Form */}
              <div className="bg-white p-8 rounded-lg shadow-lg border-2 border-wood-light/40 wood-texture">
                <h2 className="text-2xl font-bold text-wood-dark mb-6">
                  {editingBook ? "ویرایش کتاب" : "افزودن کتاب جدید"}
                </h2>
                <form className="space-y-6">
                  <div>
                    <Label htmlFor="book-title" className="text-wood-dark font-bold mb-2 block">
                      عنوان کتاب
                    </Label>
                    <Input
                      id="book-title"
                      placeholder="عنوان کتاب را وارد کنید"
                      className="border-wood-light focus:border-wood-medium"
                      defaultValue={editingBook?.title}
                    />
                  </div>

                  <div>
                    <Label htmlFor="book-author" className="text-wood-dark font-bold mb-2 block">
                      نویسنده
                    </Label>
                    <Input
                      id="book-author"
                      placeholder="نام نویسنده را وارد کنید"
                      className="border-wood-light focus:border-wood-medium"
                      defaultValue={editingBook?.author}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="book-pages" className="text-wood-dark font-bold mb-2 block">
                        تعداد صفحات
                      </Label>
                      <Input
                        id="book-pages"
                        type="number"
                        placeholder="تعداد صفحات"
                        className="border-wood-light focus:border-wood-medium"
                        defaultValue={editingBook?.pages}
                      />
                    </div>
                    <div>
                      <Label htmlFor="book-year" className="text-wood-dark font-bold mb-2 block">
                        سال انتشار
                      </Label>
                      <Input
                        id="book-year"
                        type="number"
                        placeholder="سال انتشار"
                        className="border-wood-light focus:border-wood-medium"
                        defaultValue={editingBook?.year}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="book-description" className="text-wood-dark font-bold mb-2 block">
                      توضیحات
                    </Label>
                    <Textarea
                      id="book-description"
                      placeholder="توضیحات کتاب را وارد کنید"
                      rows={5}
                      className="border-wood-light focus:border-wood-medium"
                      defaultValue={editingBook?.description}
                    />
                  </div>

                  <div>
                    <Label htmlFor="book-cover" className="text-wood-dark font-bold mb-2 block">
                      تصویر جلد کتاب
                    </Label>
                    <Input
                      id="book-cover"
                      type="file"
                      accept="image/*"
                      className="border-wood-light focus:border-wood-medium"
                    />
                  </div>

                  <div>
                    <Label htmlFor="book-genre" className="text-wood-dark font-bold mb-2 block">
                      ژانر
                    </Label>
                    <select
                      id="book-genre"
                      className="w-full px-4 py-2 border-2 border-wood-light rounded-lg focus:border-wood-medium focus:outline-none"
                      defaultValue={editingBook?.genre}
                    >
                      <option value="">انتخاب ژانر</option>
                      <option value="fiction">داستانی</option>
                      <option value="poetry">شعر</option>
                      <option value="history">تاریخی</option>
                      <option value="philosophy">فلسفی</option>
                      <option value="science">علمی</option>
                      <option value="children">کودک و نوجوان</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="book-isbn" className="text-wood-dark font-bold mb-2 block">
                        شابک (ISBN)
                      </Label>
                      <Input
                        id="book-isbn"
                        placeholder="شابک کتاب"
                        className="border-wood-light focus:border-wood-medium"
                        defaultValue={editingBook?.isbn}
                      />
                    </div>
                    <div>
                      <Label htmlFor="book-price" className="text-wood-dark font-bold mb-2 block">
                        قیمت (تومان)
                      </Label>
                      <Input
                        id="book-price"
                        type="number"
                        placeholder="قیمت"
                        className="border-wood-light focus:border-wood-medium"
                        defaultValue={editingBook?.price}
                      />
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button className="flex-1 bg-wood-medium hover:bg-wood-dark text-white font-bold py-3">
                      {editingBook ? "ذخیره تغییرات" : "افزودن کتاب"}
                    </Button>
                    {editingBook && (
                      <Button
                        type="button"
                        onClick={handleCancelEdit}
                        className="bg-gray-500 hover:bg-gray-600 text-white font-bold py-3"
                      >
                        انصراف
                      </Button>
                    )}
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>

      <Footer />
    </main>
  )
}
